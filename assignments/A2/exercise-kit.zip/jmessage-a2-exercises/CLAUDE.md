# Parts 2 and 3 — Claude Code instructions
@AGENTS.md
Read `AGENTS.md`, `EXERCISES.md`, and the protocol `specification.md`, together
with the starter kit's `AGENTS.md`, before doing anything else in this directory.
