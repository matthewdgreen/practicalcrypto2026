"""Your Parts 2 and 3 attacks. Fill in the entry points below.

The runner starts a fresh sandbox, calls `start` for you, and then calls one of
these functions with an `ExerciseAPI` object `api` (see API.md). You act as the
malicious relay: inspect the queue, deliver, drop, and inject protocol bodies.
You never see plaintext, keys, or any padding/MAC flag — only the wire messages
the bots emit and the limited status fields.

Copy this exercises/ directory into your client directory (your submission),
then run from the extracted kit, with <dir> that client directory:

    python run_exercises.py --submission <dir> --part 2 --output <dir>/run-part2
    python run_exercises.py --submission <dir> --part 3 --output <dir>/run-part3
    python run_exercises.py --submission <dir> --part chain --output <dir>/run-chain
    python run_exercises.py --submission <dir> --part experiment --output <dir>/run-exp

See EXERCISES.md for the task, the threat model, the evidence to submit, and the
resource limits. `recover_byte` is yours to write by hand (handout Revision 3).
"""


def downgrade(api) -> bytes:
    """Part 2. Make the two honest bots establish a JM1 session.

    Alice's initial HELLO (offering JM2 then JM1) is already queued. Using only
    the adversary operations, cause both bots to establish JM1, and return that
    session's 16-byte `sid`. For a chained run, leave the challenge DATA
    unaccepted by Bob. The runner checks both bots' real session state; a
    returned sid is a claim, not proof.
    """
    raise NotImplementedError("Part 2: downgrade")


def recover_byte(prev_block: bytes, forged_prev: bytes, position: int) -> int:
    """Return the plaintext byte at `position` of the target block. WRITE THIS YOURSELF.

    This is the one piece of the attack you must write by hand, not generate
    (handout Revision 3, "Write this yourself"). Above it, add a two- or
    three-line comment deriving it from how CBC decryption works.

    `prev_block` is the genuine ciphertext block (or the IV) that precedes the
    target block in the record. `forged_prev` is the previous block you sent
    that made the oracle report valid padding, with the bytes after `position`
    already fixed to produce the matching padding value. Return the recovered
    plaintext byte (0-255).

    Your `recover` must call this for every byte it reports.
    """
    raise NotImplementedError("Part 3: recover_byte (write this yourself)")


def recover(api, target) -> dict:
    """Part 3. Recover the plaintext of the captured JM1 record `target`.

    `target` is the decoded original DATA envelope (its `body` is bytes). Return:

        {"plaintext": <bytes or None>, "blocks": {block_index: <16 bytes>, ...}}

    `plaintext` excludes the HMAC and padding. `blocks` is optional evidence of
    progress: each value is a recovered 16-byte block of the CBC-decrypted
    padded string, zero-indexed in ciphertext order (the IV is not block 0).
    Return None for `plaintext` if you did not recover the whole message.
    Obtain every recovered byte through `recover_byte`.
    """
    raise NotImplementedError("Part 3: recover")


def experiment(api) -> None:
    """Optional diagnostic for Part 2's write-up (offer-stripping).

    A fresh negotiation sandbox is started for you. Try to strip JM2 from the
    HELLO and observe why the handshake does not complete. This produces a
    transport trace you can cite; it earns no execution verdict by itself and
    is expected not to establish a session.
    """
    raise NotImplementedError("optional: offer-stripping experiment")
